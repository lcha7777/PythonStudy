package com.mvc.emp.biz;

import java.util.List;

import com.mvc.emp.dto.EmpDto;

public interface EmpBiz {
	
	public List<EmpDto> selectList();

}
